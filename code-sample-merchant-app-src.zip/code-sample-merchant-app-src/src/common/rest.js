'use strict';

angular.module('netincent.rest', [])
  .config(['$provide', '$httpProvider', function ($provide, $httpProvider) {

    $provide.factory('commonrest', function() {
      return {
        response: function (response) {
          if (response.status === 401 || response.status === 403 || response.status === 500) {
            window.location.replace('login.html');
            return;
          }

          // unwrap responses easily
          var ret = response,
            req = response.config;
          switch (req.unwrap) {
            case 'single': ret = (ret.data && ret.data[0]); break;
            case true    : ret = ret.data; break;
          }

          function parseDate(input, format) {
            // 2014-07-22 05:10:06.284
            format = format || 'yyyy-mm-dd HH:MM:SS.MSS'; // default format
            var parts = input.match(/(\d+)/g),
              i = 0, fmt = {};
            // extract date-part indexes from the format
            format.replace(/(yyyy|dd|mm|HH|MM|SS|MSS)/g, function(part) { fmt[part] = i++; });

            var dt = new Date();
            dt.setUTCFullYear(parts[fmt.yyyy], parts[fmt.mm]-1, parts[fmt.dd]);
            dt.setUTCHours(parts[fmt.HH], parts[fmt.MM]-1, parts[fmt.SS], parts[fmt.MSS]);
            return dt;

            /*return new Date(parts[fmt.yyyy], parts[fmt.mm]-1, parts[fmt.dd],
              parts[fmt.HH], parts[fmt.MM]-1, parts[fmt.SS], parts[fmt.MSS]
            );*/
          }


          if (req.xform) {
            (ret instanceof Array ? ret : [ret]).forEach(function (rec) {
              if (ret && req.xform.date) {
                req.xform.date.split(',').forEach(function (fld) {
                  if (rec[fld]) { rec[fld] = parseDate(rec[fld]); }
                });
              }
              if (ret && req.xform.dateRed) {
                req.xform.dateRed.split(',').forEach(function (fld) {
                   if (rec[fld]) {

                     /* var dateToConvert = rec.redeem_date.replace(/(\d) (\d)/, '$1T$2')
                      var convertedDateString = dateToConvert.toLocaleString();
                      convertedDateString = convertedDateString.replace('at ', '');
                      var date_ = new Date(convertedDateString);
                      rec[fld]= date_; }
*/

                      var date_ = new Date(rec.redeem_date.replace(/(\d) (\d)/, '$1T$2'));
                      rec[fld]= date_; }
                    });
              } ///

                //var time_str = rec.redeem_date.replace(/.* (\d+:\d+).*/, '$1');
                //var date_str = date_.toDateString() + ' ' + time_str;
                //var date_ = new Date();
              ///  var time_str = date_.toTimeString().split(' ')};
               // var time_str = date_.toTimeString();
              ///  rec[fld] = date_.toDateString('MMM d yyyy, h:mm tt') +' , ' + time_str[0] ;}
                ///    );
            ///  }
              if (ret && req.xform.dateRew) {
                req.xform.dateRew.split(',').forEach(function (fld) {
                   if (rec[fld]) {
                      var date_ = new Date(rec.txn_date.replace(/(\d) (\d)/, '$1T$2'));
                      rec[fld]= date_; }
                    });
              }
              if (ret && req.xform.datePunch) {
                req.xform.datePunch.split(',').forEach(function (fld) {
                   if (rec[fld]) {
                      //var date_ = new Date(rec.txn_date.replace(/(\d) (\d)/, '$1T$2'));
                      var date_ = new Date(rec.txn_date.$date);
                    //var date_ = rec.txn_date.$date;
                      rec[fld]= date_; }
                    });
              }
              if (ret && req.xform.dateRedBE) {
                              req.xform.dateRedBE.split(',').forEach(function (fld) {
                                 if (rec[fld]) {
                                    var date_ = new Date(rec.redeem_date.$date);
                                    rec[fld]= date_; }
                                  });
              }
              if (ret && req.xform.number) {
                req.xform.number.split(',').forEach(function (fld) {
                  if (rec[fld]) { rec[fld] = Number(rec[fld]); }
                });
              }
            });
          }

          return ret;
        }
      };
    });

    $httpProvider.interceptors.push('commonrest');

  }])
;
