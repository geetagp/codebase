'use strict';

(function () {

  angular.module('netincent.all', ['netincent.ui.util']);

  angular.module('netincent.ui.util', [])

    .filter('branding', function (brandingConstants, $rootScope) {
      var set;
      return function (value, key) {
        set = set || brandingConstants[value || $rootScope.$merchant.brand];
        return set[key] || '';
      };
    })

    .filter('iif0', function () {
      return function (value, iflt0, if0, ifgt0) {
        return !isNaN(Number(value)) && (Number(value) > 0 ? ifgt0 : value < 0 ? iflt0 : if0);
      };
    })

    .filter('bonus', function () {
      return function (multiplier) {
        return Math.round((multiplier-1) * 100);
      };
    })

    .service('CSV', function () {
      var service;
      return (service = {
        fromHTMLTable: function ($table) {
          var $headers = $table.find('tr:has(th)'),
            $rows = $table.find('tr:has(td)'),

          // Temporary delimiter characters unlikely to be typed by keyboard
          // This is to avoid accidentally splitting the actual contents
            tmpColDelim = String.fromCharCode(11), // vertical tab character
            tmpRowDelim = String.fromCharCode(0), // null character

          // actual delimiter characters for CSV format
            colDelim = '","',
            rowDelim = '"\r\n"';

          // Grab text from table into CSV formatted string
          var csv = '"';
          csv += formatRows($headers.map(grabRow));
          csv += rowDelim;
          csv += formatRows($rows.map(grabRow)) + '"';

          return csv;


          //------------------------------------------------------------
          // Helper Functions
          //------------------------------------------------------------
          // Format the output so it has the appropriate delimiters
          function formatRows(rows){
            return rows.get().join(tmpRowDelim)
              .split(tmpRowDelim).join(rowDelim)
              .split(tmpColDelim).join(colDelim);
          }
          // Grab and format a row from the table
          function grabRow(i, row){

            var $row = $(row);
            //for some reason $cols = $row.find('td') || $row.find('th') won't work...
            var $cols = $row.find('td');
            if(!$cols.length) { $cols = $row.find('th'); }

            return $cols.map(grabCol)
              .get().join(tmpColDelim);
          }
          // Grab and format a column from the table
          function grabCol(j, col){
            var $col = $(col),
              $text = $col.text();

            return $text.replace(/^\s+/,'').replace(/\s+$/,'').replace('"', '""'); // escape double quotes
          }


        },
        encode: function (contents) {
          return 'data:application/csv;charset=utf-8,' + encodeURIComponent(contents);
        },
        plugLink: function ($link, $table, filename) {
          $($link).click(function () {
            $($link)
              .attr({
                'download': filename || 'export.csv',
                'href': service.encode(service.fromHTMLTable($($table)))
                //,'target' : '_blank' //if you want it to open in a new window
              });
          });
        }
      });
    })

    .controller('DynamicTableCtrl', function ($scope, $filter, $timeout) {
      var init;

      $scope.searchKeywords = '';
      $scope.filteredList = [];
      $scope.row = '';

      $scope.select = function(page) {
        var end, start;
        start = (page - 1) * $scope.numPerPage;
        end = start + $scope.numPerPage;
        return ($scope.currentList = $scope.filteredList.slice(start, end));
      };

      $scope.onFilterChange = function() {
        $scope.select(1);
        $scope.currentPage = 1;
        return ($scope.row = '');
      };

      $scope.onNumPerPageChange = function() {
        $scope.select(1);
        return($scope.currentPage = 1);
      };

      $scope.onOrderChange = function() {
        $scope.select(1);
        return ($scope.currentPage = 1);
      };

      $scope.search = function() {
        $scope.filteredList = $filter('filter')($scope.list, $scope.searchKeywords);
        return $scope.onFilterChange();
      };

      $scope.order = function(colName) {
        if ($scope.sortColumn === colName) {
          return;
        }
        $scope.sortColumn = colName;
        $scope.filteredList = $filter('orderBy')($scope.list, colName);
        return $scope.onOrderChange();
      };

      $scope.showAll = function () {
        $scope.currentList = $scope.list;
        $timeout(function () {
          init();
        }, 1000);
      };

      var All = $scope.list.length;
      $scope.numPerPageOpt = [3, 5, 10, 15, 50];
      if (All > 50) {
        $scope.numPerPageOpt.push(All);
      }


      $scope.numPerPage = $scope.numPerPageOpt[4];

      $scope.currentPage = 1;

      $scope.currentList = [];

      init = function() {
        $scope.search();
        if ($scope.sortColumn) {
          return $scope.order($scope.sortColumn);
        }
        return $scope.select($scope.currentPage);
      };

      init();
    })

     .controller('DynamicTableCtrl1', function ($scope, $filter, $timeout) {
          var init;

          $scope.searchKeywords = '';
          $scope.filteredList1 = [];
          $scope.row = '';

          $scope.select = function(page) {
            var end, start;
            start = (page - 1) * $scope.numPerPage;
            end = start + $scope.numPerPage;
            return ($scope.currentList1 = $scope.filteredList1.slice(start, end));
          };

          $scope.onFilterChange = function() {
            $scope.select(1);
            $scope.currentPage = 1;
            return ($scope.row = '');
          };

          $scope.onNumPerPageChange = function() {
            $scope.select(1);
            return($scope.currentPage = 1);
          };

          $scope.onOrderChange = function() {
            $scope.select(1);
            return ($scope.currentPage = 1);
          };

          $scope.search = function() {
            $scope.filteredList1 = $filter('filter')($scope.list1, $scope.searchKeywords);
            return $scope.onFilterChange();
          };

          $scope.order = function(colName) {
            if ($scope.sortColumn === colName) {
              return;
            }
            $scope.sortColumn = colName;
            $scope.filteredList1 = $filter('orderBy')($scope.list1, colName);
            return $scope.onOrderChange();
          };

          $scope.showAll = function () {
            $scope.currentList1 = $scope.list1;
            $timeout(function () {
              init();
            }, 1000);
          };

          var All = $scope.list1.length;
          $scope.numPerPageOpt = [3, 5, 10, 15, 50];
          if (All > 50) {
            $scope.numPerPageOpt.push(All);
          }


          $scope.numPerPage = $scope.numPerPageOpt[4];

          $scope.currentPage = 1;

          $scope.currentList1 = [];

          init = function() {
            $scope.search();
            if ($scope.sortColumn) {
              return $scope.order($scope.sortColumn);
            }
            return $scope.select($scope.currentPage);
          };


          //****calender date popup code

          $scope.today = function() {
             $scope.dt = new Date();
          };

          $scope.clear = function () {
              $scope.dt = null;
          };

          $scope.open = function($event) {
              $event.preventDefault();
              $event.stopPropagation();

              $scope.opened = true;
          };

         $scope.open1 = function($event) {
              $event.preventDefault();
              $event.stopPropagation();

              $scope.opened1 = true;
          };

          $scope.dateOptions = {
          };

          $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MMM d, y'];
          $scope.format = $scope.formats[4];

          //*** end of calender date popup code

          init();
        })


    .directive('exportTable', function (CSV) {
      return function ($scope, $element) {
        CSV.plugLink($element, $($element).attr('export-table'), $($element).attr('export-table-as'));
      };
    })

  ;

  Array.prototype.accumulate = function(fn) {
    fn = fn || function (a, b) { return a + b; }; // default is to sum/concat it up
    var r = [this[0]];
    this.reduce(function(a, b) {
      return (r[r.length] = fn(a, b));
    });
    return r;
  };

})();
