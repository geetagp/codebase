'use strict';

angular.module('netincent.appery', ['ngStorage', 'netincent.config'])
  .config(['$provide', '$httpProvider', function ($provide, $httpProvider) {

    // register the interceptor as a service
    $provide.factory('apperization', function($window, apperyConstants) {
      var apperize = function (url, fn) {
        url = (fn ? '' : 'db/') + url;
        return (apperyConstants.baseURL + '/' + url).replace(/\/+/g, '/').replace(/(https?):\/+/, '$1://');
      };
      return {
        request: function(config) {
          var sStore = $window.sessionStorage,
            merch = sStore && sStore.merchant && JSON.parse(sStore.merchant);

          // intercept any appery.io requests .. tweak URL
          if (config.fn && (config.fn.indexOf('/appery/') > -1 || config.fn.indexOf('appery/') > -1)) {
            // support easy to execute functions
            config.fnCode = apperyConstants[config.fn.replace(/appery\/?/, '')];
            config.url = 'appery/code/' + config.fnCode + '/exec';
          }
          if (config.url.indexOf('/appery/') > -1 || config.url.indexOf('appery/') > -1) {
            // appery defaults
            config.dataType = 'json';
            config.contentType = 'application/json';
            config.url = apperize(config.url.replace(/^\/?appery\//, ''), config.fnCode);
            config.headers['X-Appery-Database-Id'] = apperyConstants.dbID;
            if (config.skipSessionToken !== true && sStore.sessionToken) {
              config.headers['X-Appery-Session-Token'] = sStore.sessionToken;
            }
          }
          config.params  = config.params || {};
          if (config.projection) {
            var p = {};
            (config.projection.include||'').split(',').forEach(function (str) { if (str) { p[str] = 1; } });
            (config.projection.exclude||'').split(',').forEach(function (str) { if (str) { p[str] = 0; } });
            config.params.proj = p;
          }


          if (config.demoClause) {
            var demoClause = { demo: (merch && merch.demo) || false},
              pr = config.params || {};

            if (pr.hasOwnProperty('where')) {
              if (pr.where.hasOwnProperty('$and') && pr.where.$and instanceof Array) {
                pr.where.$and.push(demoClause);
              }
              else {
                pr.where = { $and: [ pr.where, demoClause ] };
              }
            }
            else {
              pr.where = demoClause;
            }
          }

          if (config.moreList) {
            config.params.limit = 1500;
          }


          return config;
        }
      };
    });

    $httpProvider.interceptors.push('apperization');
  }])
;
