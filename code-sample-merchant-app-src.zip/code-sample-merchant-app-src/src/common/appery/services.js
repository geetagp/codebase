'use strict';

(function () {

  var enc = function (o) { return JSON.stringify(o); };

  angular.module('netincent.appery')
    .service('Session', function ($http, $window) {
      var currentMerchantId,
        isCurrentMerchantDemo = false;

      return {
        checkValid: function () {
          return $http({
            method: 'GET',
            url: 'appery/users',
            unwrap: true
          });
        },
        doLogin: function (uname, pwd) {
          return $http({
            method: 'GET',
            url: 'appery/login',
            params: { username: uname, password: pwd },
            skipSessionToken: true,
            unwrap: true
          });
        },
        doLogout: function () {
          return $http({
            method: 'GET',
            url: 'appery/logout',
            unwrap: true
          });
        },
        isDemo: function () {
          var m = $window.sessionStorage.merchant;
          return (isCurrentMerchantDemo = (isCurrentMerchantDemo === undefined ? m.demo === true : isCurrentMerchantDemo || false));
        },
        getCurrentUser: function (uname) {
          return $http({
            method: 'GET',
            url: 'appery/users',
            params: { where : { username: uname } },
            unwrap: 'single'
          });
        },
        resetPasswordSendSecret: function (mobileNumber) {
          return $http({
            fn: 'appery/fnSendRecoveryInfoText',
            params: { merchuser: mobileNumber },
            skipSessionToken: true,
            unwrap: true
          });
        },
        resetPassword: function (mobileNumber, secretCode, newPassword) {
          return $http({
            fn: 'appery/fnResetPassword',
            params: { merchuser: mobileNumber, newPassword: newPassword, secretCode: secretCode },
            skipSessionToken: true,
            unwrap: true
          });
        },
        setCurrentMerchant: function (merchant) {
          if (merchant && merchant._id) {
            $window.sessionStorage.merchant = JSON.stringify(merchant);
            currentMerchantId = merchant._id;
            isCurrentMerchantDemo = merchant.demo === true;
          }
        },
        getMerchantId: function () {
          var m = $window.sessionStorage.merchant;
          m = currentMerchantId || (m ? JSON.parse(m) : null);
          return m && m._id;
        }
      };
    })

    .service('System', function ($http, $q) {
      var CONFIG = {globals: {}, enrollmentBonus: {}},
        service;

      return (service = {
        init: function () {

          return $q.all([globals(), bonuses(), subsidies()]);

          function globals() {
            return $http({
              method: 'GET',
              url: 'appery/collections/Globals',
              unwrap: true
            }).then(function (response) {
              var cfg = CONFIG.globals = {};
              response.forEach(function (each) { cfg[each.name] = each.value; });
              return cfg;
            });
          }

/*
          function bonuses() {
            return $http({
              method: 'GET',
              url: 'appery/collections/enrollment_bonus',
              unwrap: true
            }).then(function (response) {
              response.forEach(function (each) {
                var cfg = CONFIG.enrollmentBonus[each._id] = {},
                  threshold = cfg.threshold = [],
                  bonus = cfg.bonus = [];
                for (var i=1; i<5; i++ ) {
                  threshold.push(each['threshold'+i]);
                  bonus.push(Number(each['bonus'+i]));
                }
              });
              return response;
           });
          }

          function subsidies() {
            return $http({
              method: 'GET',
              url: 'appery/collections/merchant_subsidy',
              unwrap: true
            }).then(function (response) {
              var cfg = CONFIG.subsidies = {};
              response.forEach(function (each) {
                var arr = cfg[each.merchant_id] = cfg[each.merchant_id] || [];
                arr.push({
                  start : each.start_date,
                  end   : each.end_date,
                  amount: each.daily_subsidy
                });
              });
              return cfg;
            });
          }
        },
*/
        function bonuses() {

           return $http({
              fn: 'appery/fnGetMerchantStats',
              params: {
                    getEnrollmentBonus: "getEnrollmentBonus"},
                    unwrap: true
              }).then(function (response) {
                response.forEach(function (each) {
                  var cfg = CONFIG.enrollmentBonus[each._id] = {},
                    threshold = cfg.threshold = [],
                    bonus = cfg.bonus = [];
                  for (var i=1; i<5; i++ ) {
                    threshold.push(each['threshold'+i]);
                    bonus.push(Number(each['bonus'+i]));
                  }
                });
                return response;
             });
            }

        function subsidies() {
            return $http({
               fn: 'appery/fnGetMerchantStats',
               params: {
                  getMerchantSubsidy: "getMerchantSubsidy"},
                  unwrap: true
               }).then(function (response) {
                var cfg = CONFIG.subsidies = {};
                response.forEach(function (each) {
                  var arr = cfg[each.merchant_id] = cfg[each.merchant_id] || [];
                  arr.push({
                    start : each.start_date.$date,
                    end   : each.end_date.$date,
                    amount: each.daily_subsidy
                  });
                });
                return cfg;
              });
            }
        },


        getGlobal: function (name) {
          return CONFIG.globals[name];
        },

        /*
        calculateEnrollmentBonus: function (bonusId, value) {
          var cnt = 0,
            sum = 0,
            cfg = CONFIG.enrollmentBonus[bonusId];
          while (cfg && value > 0 && cnt < 4) {
            sum += (Math.min(cfg.threshold[cnt], value) * cfg.bonus[cnt]);
            value -= cfg.threshold[cnt];
            cnt++;
          }
          return sum;
        },

        calculateSubsidies: function (merchId) {
          var now = new Date(),
            oneDay = 24*60*60*1000,
            cfg = CONFIG.subsidies[merchId] || [],
            start,
            end,
            duration,
            days,
            sum = 0
          ;
          now = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          cfg.forEach(function (s) {
            start = new Date(s.start.replace(/-/g, '/').split('.')[0]);
            end = new Date(s.end.replace(/-/g, '/').split('.')[0]);
            duration = (end - start) / oneDay;
            days = now > end ? duration : start > now ? 0 : (now - start) / oneDay;
            sum += (days * Number(s.amount));
          });
          return sum;
        }
        */

        calculateEnrollmentBonus: function (bonusId, value) {
          var cnt = 0,
            sum = 0,
            cfg = CONFIG.enrollmentBonus[bonusId];
          while (cfg && value > 0 && cnt < 4) {
            sum += (Math.min(cfg.threshold[cnt], value) * cfg.bonus[cnt]);
            value -= cfg.threshold[cnt];
            cnt++;
          }
          return sum;
        },

        calculateSubsidies: function (merchId) {
            var now = new Date(),
            oneDay = 24*60*60*1000,
            cfg = CONFIG.subsidies[merchId] || [],
            start,
            end,
            duration,
            days,
            sum = 0;

          now = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          cfg.forEach(function (s) {
            start = new Date(s.start);
            end = new Date(s.end);
            duration = (end - start) / oneDay;
            days = now > end ? duration : start > now ? 0 : (now - start) / oneDay;
            sum += (days * Number(s.amount));
          });
          return sum;
        }

      });
    })

    .service('Merchants', function ($http, $q, $rootScope, Session) {
      var service;
      return (service = {
        get: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $http({
            url: 'appery/collections/Merchants',
            params: {
              where: enc({ _id: merchId })
            },
            unwrap: 'single'
          });
        },
        getCustomers: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $q.all([service.getRedemptions(merchId), service.getRewards(merchId), service.getEnrolledCustomers(merchId)])
            .then(function (results) {
              var red = (results[0]||[]).map(function (o) { return o.customer_userid; }),
                rew   = (results[1]||[]).map(function (o) { return o.customer_user; }),
                enr   = (results[2]||[]).map(function (o) { return o._id; });
              return d3.set(red.concat(rew , enr)).values();
            })
            ;
        },
        /*
        getPayments: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $http({
            url: 'appery/collections/merchant_payments',
            params: {
              where: enc({ merchant_id: merchId })
            },
            unwrap: true
          });
        },*/
        getPayments: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
           fn: 'appery/fnGetMerchantStats',
           params: { merchId: merchId ,
                     getPayments: "getPayments"},
           unwrap: true
           });
        },
        getTransactions: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $q.all([service.getRedemptions(merchId), service.getRewards(merchId)])
            .then(function (redemptions, rewards) {
              return redemptions.concat(rewards);
            }
          );
        },
        /*/
        getEnrolledCustomers: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $http({
            fn: 'appery/fnGetMerchantEnrolledCustomers',
            params: { merchantid: merchId },
            xform: { date: 'enroll_date' },
            unwrap: true
          });
        },
        */
        getEnrolledCustomers: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
              fn: 'appery/fnGetMerchantStats',
              params: { merchId: merchId ,
              getEnrolledCustomers: "getEnrolledCustomers"},
              unwrap: true
           });
        },
        getOffers: function (merchId, full) {
          merchId = merchId || Session.getMerchantId();
          var reqCfg = {
            url: 'appery/collections/Offers',
            params: {
              sort: 'offer_position',
              where: { $and: [{merchant_id: merchId}, {active: true}] }
            },
            unwrap: true,
            xform: { date: '_createdAt,_updatedAt' }
          };
          if (full !== true) {
            reqCfg.params.where = {
              $and: [
                reqCfg.params.where,
                { active: true }
              ]
            };
          }
          return $http(reqCfg);
        },
        getTokenOffers: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
             fn: 'appery/fnGetTokenInfo',
             params: { merchID: merchId },
             //xform: { date: 'enroll_date' },
             unwrap: true
          });
        },

        getActiveTokenOffers: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
              fn: 'appery/fnGetTokenInfo',
              params: { merchID: merchId, active : true},
                       //xform: { date: 'enroll_date' },
                       unwrap: true
              });
        },

        getActiveSysOffers: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
              fn: 'appery/fnGetTokenInfo',
              params: { merchID: merchId, sysactive : true},
                       //xform: { date: 'enroll_date' },
                       unwrap: true
              });
        },

       getTHRTiers: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
              fn: 'appery/fnGetTokenInfo',
              params: { merchID: merchId, thrtiers : true},
                       //xform: { date: 'enroll_date' },
                       unwrap: true
              });
        },

        getRedemptions: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $http({
            url: 'appery/collections/Redemptions',
            params: {
              sort: '-redeem_date',
              where: { $and: [{merchant: merchId}, {type: 'Store'}] }
            },
            moreList: true,
            demoClause: true,
            unwrap: true,
            xform: { dateRed: 'redeem_date', number: 'amount' }
            //xform: { number: 'amount' }
          });
        },
        getRedemptionsBE: function (merchID) {
                  merchID = merchID || Session.getMerchantId();
                  return $http({
                         fn: 'appery/fnGetMerchantInfo-v2',
                         params: {redemptionEntries: "redemptionEntries", merchID: merchID},
                         unwrap: true,
                         xform: { dateRedBE: 'redeem_date', number: 'amount' }
                         });

        },
        getRewards: function (merchId, full) {
          merchId = merchId || Session.getMerchantId();
          var reqCfg = {
            url: 'appery/collections/Rewards',
            params: {
              sort: '-txn_date',
              where: { merchant: { collName: 'Merchants', _id: merchId } }
            },
            moreList: true,
            demoClause: true,
            unwrap: true,
            xform: { dateRew: 'txn_date', number: 'reward_amount,merch_cost,txn_amount' }
          };
          if (full !== true) {
            reqCfg.projection = {
              include: '_id,merchant,merchant_user,customer_user,demo,txn_amount,txn_date,reward_amount,merch_cost,collected,paid'
            };
          }
          return $http(reqCfg);
        },
        getRewardsBE: function (merchID, full) {
          merchID = merchID || Session.getMerchantId();
          return $http({
                 fn: 'appery/fnGetMerchantInfo-v2',
                 params: {rewardEntries: "rewardEntries", merchID: merchID},
                 unwrap: true,
                 xform: { datePunch: 'txn_date', number: 'reward_amount,merch_cost,txn_amount' }
                 });

        },

        getRedemptionsS: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
              fn: 'appery/fnGetMerchantStats',
              params: { merchId: merchId ,
                        getRedemptions: "getRedemptions"},
                        unwrap: true
           });
        },

        getRewardsS: function (merchId) {
           merchId = merchId || Session.getMerchantId();
           return $http({
               fn: 'appery/fnGetMerchantStats',
               params: { merchId: merchId ,
                         getRewards: "getRewards"},
                         unwrap: true
           });
        },

        getTiers: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $http({
            url: 'appery/collections/HatThresholds',
            params: { where: { merch_id: merchId } },
            unwrap: 'single',
            xform: { number: 't1_value,t1_mul,t2_value,t2_mul,t3_value,t3_mul,months' }
          }).then(function (thr) {
            var tiers = [];
            if (thr) {
              [1,2,3].forEach(function (t) {
                var prefix = 't'+t+'_';
                tiers.push({
                  name      : thr[prefix+'name'],
                  value     : thr[prefix+'value'],
                  multiplier: thr[prefix+'mul'],
                  months    : thr.months
                });
              });
            }
            return tiers;
          });
        },
        getFeeStructure: function (feeStructureId) {
          feeStructureId = feeStructureId|| $rootScope.$merchant.fee_structure_id;
          return $http({
            url: 'appery/collections/fee_structure',
            params: {
              where: { _id: feeStructureId }
            },
            unwrap: 'single'
          }).then(function (m) {
            return [
              { min: 0           , max: m.threshold1, fee: m.fee1 },
              { min: m.threshold1, max: m.threshold2, fee: m.fee2 },
              { min: m.threshold2, max: m.threshold3, fee: m.fee3 },
              { min: m.threshold3, max: null        , fee: m.fee4 }
            ];
          });
        },
        getCustomerTravel: function (merchId) {
          merchId = merchId || Session.getMerchantId();
          return $http({
            fn: 'appery/fnGetCustomersTravel',
            params: { merchantId: merchId },
            //xform: { date: 'enroll_date' },
            unwrap: true
          });
        },
        updateOffer: function (updateType, updateId) {
          return $http({
            fn: 'appery/fnGetTokenInfo',
            params:
                  {
                    updateType: updateType,
                    updateId: updateId,
                  },
            //skipSessionToken: true,
            unwrap: true
          });
        },
        updateBanner: function (updateType, updateId, bannerText) {
          return $http({
            fn: 'appery/fnGetTokenInfo',
            params:
                  {
                    updateType: updateType,
                    updateId: updateId,
                    bannerText: bannerText
                  },
            //skipSessionToken: true,
            unwrap: true
          });
        },
        createOffer: function (dataobj) {
          return $http({
                 url: 'appery/collections/Offers',
                      data: dataobj,
                      method: 'POST',
                      unwrap: true
                 }
          );
        },
        createToken: function (dataobj) {
          return $http({
                 url: 'appery/collections/Tokens',
                      data: dataobj,
                      method: 'POST',
                      unwrap: true
                 }
          );
        },
        getOverPayment: function (params) {
          return $http({
            fn: 'appery/fnGetMerchantCollected',
            params: params,
            skipSessionToken: true,
            unwrap: true
          });
        },
        getBuzzubFees: function (merchId) {
          return $http({
            fn: 'appery/fnGetMerchantInfo-v2',
            params: { merchID: merchId ,
                     buzzubFees: "buzzubFees"},
            skipSessionToken: true,
            unwrap: true
          });
        },
        getPunchTrns: function (merchId) {
          return $http({
            fn: 'appery/fnGetMerchantCollected',
            params: { merchID: merchId ,
                     punchtrns: "punchtrns"},
            skipSessionToken: true,
            unwrap: true
          });
        }

      });
    })




    // -------------- to be fleshed out still --------------- //

    .factory('ApperyPaginator', function ($http) {
      var defaults = {
        list: {
          config: {},
          params: {
            sort: '_createdAt',
            limit: 50,
            skip: 0
          }
        }
      };
      return {
        getInstance: function (baseUrl, config) {
          config = config = angular.extend({
            url: ('appery/' + baseUrl).replace(/\/+/g, '/')
          }, defaults.list.config, config);
          return {
            listFor: function (recId, params) {
              var cfg = angular.extend({}, config);
              cfg.params = angular.extend({
                where: enc({ _id: recId })
              }, defaults.list.params, params);
              return $http(cfg);
            }
          };
        }
      };
    })

    .service('Offers', function (ApperyPaginator) {
      return ApperyPaginator.getInstance('collections/Offers');
    })

  ;

})();
