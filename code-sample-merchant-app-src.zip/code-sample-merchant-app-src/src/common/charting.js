'use strict';

(function () {

  angular.module('netincent.ui.charting', [])

    .constant('Charting', {
      dashboard: {
        sparklines: function (yAxisPrefix) {
          return {
            chart: {
              type: 'lineChart',
              height: 50,
              margin: {
                top: 5,
                right: 5,
                bottom: 5,
                left: 5
              },
              useInteractiveGuideline: true,
              transitionDuration: 250,
              showXAxis: false,
              showYAxis: false,
              showLegend: false,
              x: function (d) { return new Date(d.key).getTime(); },
              y: function (d) { return d.values; },
              xAxis: {
                tickFormat: function (d) {
                  return d3.time.format('%b-%d \'%y')(new Date(d));
                }
              },
              yAxis: {
                tickFormat: function (d) {
                  return (yAxisPrefix || '') + d.toFixed(2);
                }
              }
            }
          };
        }
      }
    }
  )
  ;

})();
