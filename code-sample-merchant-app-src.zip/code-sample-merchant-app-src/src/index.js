'use strict';
angular.module('merchantWebapp', ['netincent.config', 'netincent.appery'])
  .run(function ($window, Session) {
    var qs = $window.location.search;
    Session.checkValid()
      .then(
      function () { $window.location.replace('app.html' + (qs||'')); },
      function () { $window.location.replace('login.html' + (qs||'')); }
    );
  })
;
