'use strict';

angular.module('merchantWebapp', [
  'ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngStorage', 'ui.router', 'ui.bootstrap', 'nvd3',
  'netincent.config', 'netincent.rest', 'netincent.ui.charting', 'netincent.ui.util',
  'netincent.appery'
])
  .config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('dashboard', {
        url: '/',
        templateUrl: 'app/dashboard/dashboard.html',
        controller: 'DashboardCtrl as dashboard',
        resolve: {
          //redemptions       : function (Merchants) { return Merchants.getRedemptionsBE(); },
          //rewards           : function (Merchants) { return Merchants.getRewardsBE(); },
          //redemptions       : function (Merchants) { return Merchants.getRedemptionsS(); },
          //rewards           : function (Merchants) { return Merchants.getRewardsS(); },
          //enrolledCustomers : function (Merchants) { return Merchants.getEnrolledCustomers(); },
          //payments          : function (Merchants) { return Merchants.getPayments(); },
          //merchant          : function ($rootScope) { return $rootScope.$merchant; }
        }
      })
      .state('rewards', {
        url: '/rewards',
        templateUrl: 'app/rewards/rewards.html',
        controller: 'RewardsCtrl as rewards',
        resolve: {
          rewards           : function (Merchants) { return Merchants.getRewardsBE(null, true); }
        }
      })
      .state('redemptions', {
        url: '/redemptions',
        templateUrl: 'app/redemptions/redemptions.html',
        controller: 'RedemptionsCtrl as redemptions',
        resolve: {
          redemptions       : function (Merchants) { return Merchants.getRedemptionsBE(); }
        }
      })
      .state('offers', {
        url: '/offers',
        templateUrl: 'app/offers/offers.html',
        controller: 'OffersCtrl as offers',
        resolve: {
          offers            : function (Merchants) { return Merchants.getOffers(null, true); },
          //toffers           : function (Merchants) { return Merchants.getTokenOffers(null); }
          toffers           : function (Merchants) { return Merchants.getActiveTokenOffers(null); },
          soffers           : function (Merchants) { return Merchants.getActiveSysOffers(null); },
          thrtiers          : function (Merchants) { return Merchants.getTHRTiers(null); }


        }
      })
      .state('account', {
        url: '/account',
        templateUrl: 'app/account/account.html',
        controller: 'AccountCtrl as account',
        resolve: {
          redemptions       : function (Merchants)  { return Merchants.getRedemptions(); },
          rewards           : function (Merchants)  { return Merchants.getRewardsBE(); },
          enrolledCustomers : function (Merchants)  { return Merchants.getEnrolledCustomers(); },
          merchant          : function ($rootScope) { return $rootScope.$merchant; },
          tiers             : function (Merchants)  { return Merchants.getTiers(); },
          fees              : function (Merchants)  { return Merchants.getFeeStructure(); }
        }
      })
      .state('logout', {
        url: '/logout',
        template: '',
        resolve: {
          logout: function (Session, $window) {
            return Session.doLogout().then(function () {
              $window.location.replace('index.html');
            });
          }
        }
      })
    ;

    $urlRouterProvider.otherwise('/');
  })

  .run(function ($rootScope, $state, $window, System) {
    $rootScope.$state = $state;

    // initialize system-wide info (for future calculations etc.)
    System.init().then(function () {
      $state.go('dashboard');
    });

    $rootScope.$on('$stateChangeError', function (event, controller, data, route, o, httpResponse) {
      if (httpResponse.status === 400 || httpResponse.status === 401 || httpResponse.status === 403) {
        $window.location.href = 'login.html';
      }
    });
  })

  .controller('AppCtrl', function ($window, $rootScope) {
    var m = $window.sessionStorage.merchant;
    if (m) {
      $rootScope.$merchant = JSON.parse(m);
    }
  })

;
