'use strict';

angular.module('merchantWebapp')
  .controller('AccountCtrl', function ($scope, $rootScope, Charting, merchant, fees, tiers, rewards, redemptions) {
    $scope.merchant = merchant;
    $scope.fees = fees;
    $scope.tiers = tiers;
    $scope.sortColumn = '-_createdAt';


    function plugCalculations(o, props) {
      props.split(',').forEach(function (prop) {
        var v = o[prop];
        v.net = v.earned - v.used;
      });
    }

    var m = merchant,
      r,
      l = $scope.loyalty = {};

    l.rewards = {
      earned: d3.sum((rewards||[]).map(function (o) { return o.reward_amount || 0; })),
      used: d3.sum((rewards||[]).map(function (o) { return o.collected === true ? o.reward_amount : 0; }))
    };
    l.enrollments = { earned: Number(m.earned_enrollment_bonus || 0), used: Number(m.used_enrollment_bonus || 0) };
    l.referrals = { earned: Number(m.earned_referral_bonus || 0), used: Number(m.used_referral_bonus || 0) };
    l.subsidy = { earned: Number(m.earned_subsidy || 0), used: Number(m.used_subsidy || 0) };

    plugCalculations(l, 'enrollments,referrals,subsidy,rewards');
    l.rewards.net *= -1;

    l.totalAmt = d3.sum([l.rewards.net, l.enrollments.net, l.referrals.net, l.subsidy.net]);

    l.recent = (l.list = rewards).reverse().slice(0, 10);

    r = $scope.redemptions = {
      earned: d3.sum((redemptions||[]).map(function (o) { return o.amount || 0; })),
      used  : d3.sum((redemptions||[]).map(function (o) { return o.paid === true ? o.amount : 0; }))
    };
    r.net = r.earned - r.used;
    r.totalAmt = r.net;

    r.recent = (r.list = redemptions).reverse().slice(0, 10);



  });
