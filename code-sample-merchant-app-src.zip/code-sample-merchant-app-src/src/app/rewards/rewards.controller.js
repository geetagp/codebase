'use strict';

angular.module('merchantWebapp')
  .controller('RewardsCtrl', function ($scope, $rootScope, Charting, rewards, $filter) {
    $scope.list = rewards;

    // *** Begin - compute daily rewards totals for last 7 days
    var
    weekelyrewards,
    dailyrewards,
    today = new Date(),
    y = today.getFullYear(),
    m = today.getMonth(),
    d = today.getDate(),
    startDate = new Date(y, m, d-6), // -6 for seven days including today
    endDate = new Date(y, m, d, 23,59,59,999);
    //startDate = new Date(y-1, m-5, d), // test date
    //endDate = new Date(y, m, d, 23,59,59,999); // test date
    if (startDate && endDate) {
      weekelyrewards = _.filter(rewards,
      function(o){ return o.txn_date  >= startDate && o.txn_date  <= endDate;});
    }
    var dtostr = $filter('date');
    $scope.list1 = d3.nest()
          .key(function(d) { return dtostr(d.txn_date,  'mediumDate');}) // en_US locale format
          .rollup(function(leaves) { return {"sortKey": leaves[0].txn_date, "length": leaves.length, "amount": d3.sum(leaves, function(d) {return d.reward_amount;})} })
          .entries(weekelyrewards); //sortKey for sorting, key in medium format does not allow to sort on date

    // *** End - compute daily rewards total for last 7 days

    // *** Begin - on selection of start date and end date from calender, display total
    $scope.selectStartDate = function (dtStart) {
          var dtostr = $filter('date');
          // - set default for endDate (=startDate) on select of startDate
          //$scope.dtEnd = dtostr(dtStart, 'mediumDate');
          // - works initially, but will not get default once endDate is changed using calender
          var sDate = dtStart , eDate ;
          $scope.totalRewards = 0.00;
          $scope.beginDate = dtStart;
          if ( typeof $scope.endingDate == "undefined"){
             eDate = dtStart;
          }else{ eDate =  $scope.endingDate; }

          $scope.list2 =[];
          calculateRewardsTotal(sDate, eDate, $scope);
    };
    $scope.selectEndDate = function (dtEnd) {
          var eDate = dtEnd, sDate= $scope.beginDate;
          $scope.endingDate = dtEnd;
          if ( typeof $scope.endingDate == "undefined"){ // if end date is cleared get totals for start date
             eDate = $scope.beginDate;
          }
          $scope.list2 =[];
          calculateRewardsTotal(sDate, eDate, $scope);
    }
    function calculateRewardsTotal(sDate, eDate, $scope){
        var
        sy =  sDate.getFullYear(),
        sm =  sDate.getMonth(),
        sd =  sDate.getDate(),
        ey =  eDate.getFullYear(),
        em =  eDate.getMonth(),
        ed =  eDate.getDate(),
        startDate = new Date(sy, sm, sd),
        endDate = new Date(ey, em, ed, 23,59,59,999);

        //console.log("StartDate: " + startDate + "EndDate :" + endDate + "$scope.dtEnd" + $scope.dtEnd + " $scope.endingDate" +  $scope.endingDate);
        if (startDate && endDate) {
           dailyrewards = _.filter(rewards,
           function(o){ return o.txn_date  >= startDate && o.txn_date  <= endDate;});
        }
        $scope.totalRewards = d3.nest()
          .rollup(function (gelms) { return d3.sum(gelms, function (o) { return o.reward_amount});})
          .entries(dailyrewards);
        var obj = {};
        obj.values = $scope.totalRewards;
        $scope.list2.push(obj);
    }
    // *** End -  on selection of start date and end date from calender, display total

  });
