'use strict';

angular.module('merchantWebapp')
  .controller('OffersCtrl', function ($scope, $rootScope, Charting, offers, toffers, soffers, thrtiers, Merchants, $window, $modal) {

    $scope.list = offers;
    $scope.list3 = soffers;
    $scope.soffers = soffers;
    $scope.thrtiers = thrtiers;
    $scope.allrebates = toffers;
    $scope.toBeCreated = false;

    $scope.merchant = $rootScope.$merchant;
    //console.log("merchant.brand : " +  $scope.merchant.brand );
    if ( $scope.merchant.brand == 'k4m' || $scope.merchant.brand == 'sys' || $scope.merchant.brand.indexOf( 'k4m')>-1 ||  $scope.merchant.brand.indexOf( 'sys')>-1 ){
       $('#tierID').hide();
    }

    // always show tho / show-hide thr
    //console.log(offers.length);
    $scope.showTHR = true;
    $scope.showTHO = true;
    if (offers.length > 0){
    if ((offers[0].value == 0) && (offers[0].value == 0))
    {$scope.showTHR = false;}
    }
    else{$scope.showTHR = false;
    }

    var offersList = [];
    for(var each, i = 0; i < toffers.length; i++) {

      if (toffers[i].map_location)
      {
        each = toffers[i];
        if (toffers[i].type == 'CPN')
        {
          if (toffers[i].limit_pertoken)
          {each.restr= 'Limit ' + toffers[i].limit_pertoken + ' per Customer';}
          else
          { each.restr= 'None';}
          offersList.push(each);
        }
        else if (toffers[i].type == 'NEW')
        {
           each.restr= 'New Customers Only';
           offersList.push(each);
        }
      }
    }

    $scope.list1 = [];
    $scope.list1 = offersList;

    // *** begin rebate-tokens update
   $scope.editingDataTokens = {};
    for (var i = 0, length = $scope.list1.length; i < length; i++) {
        $scope.editingDataTokens[i] = false;
    }

    $scope.modifyTokens = function(index){
        $scope.editingDataTokens[index] = true;
    };

    $scope.deleteTokens = function(index){
       var updateId = $scope.list1[index]._id;
       Merchants.updateOffer('rebate', updateId).then(function () {
           Merchants.getActiveTokenOffers(null).then(function (result){

                                   var templist = [];
                                   // filter list1 for new,cpn
                                   for(var each, i = 0; i < result.length; i++)
                                   {

                                      if (result[i].map_location)
                                      {
                                        each = result[i];
                                        if (result[i].type == 'CPN')
                                        {
                                             if (result[i].limit_pertoken)
                                             {each.restr= 'Limit ' + result[i].limit_pertoken + ' per Customer';}
                                             else
                                             { each.restr= 'None';}
                                               templist.push(each);
                                        }
                                        else if (result[i].type == 'NEW')
                                        {
                                              each.restr= "New Customers Only";
                                              templist.push(each);
                                        }
                                      }
                                   }
                                   $scope.list1 = templist;
                              });
       });
    }
    $scope.updateTokens = function(index,each){
        // validate rebate coupons
        if (isNaN(each.value)){
           $window.alert('Please enter Reward Amount as numeric value.');
           return;
        } else
        {
           var updateId = $scope.list1[index]._id;
           $scope.editingDataTokens[index] = false;
           var dataObject = {
            'batch': each.batch,
            'seq_start': each.seq_start,
            'seq_end': each.seq_end,
            'merchant_id': each.merchant_id,
            'merchant_name': each.merchant_name,
            'type': each.type,
            'value': each.value,
            'user_list': each.user_list,
            'version': each.version,
            'txn_value': each.txn_value,
            'coupon_name': each.coupon_name,
            'image': each.image,
            'limit_pertoken': each.limit_pertoken,
            'coupon_code': each.coupon_code,
            'map_location': each.map_location,
            'tiered': each.tiered,
            'token_id': each.token_id,
            'active': true,
            'acl': JSON.parse('{"*": { "read": true,"write": true}}')
          }
          Merchants.updateOffer("rebate", updateId).then(function () {
             Merchants.createToken(dataObject).then(function(){
                   Merchants.getActiveTokenOffers(null).then(function (result){

                        var templist = [];
                        // filter list1 for new,cpn
                        for(var each, i = 0; i < result.length; i++)
                        {

                           if (result[i].map_location)
                           {
                             each = result[i];
                             if (result[i].type == 'CPN')
                             {
                                  if (result[i].limit_pertoken)
                                  {each.restr= 'Limit ' + result[i].limit_pertoken + ' per Customer';}
                                  else
                                  { each.restr= 'None';}
                                    templist.push(each);
                             }
                             else if (result[i].type == 'NEW')
                             {
                                   each.restr= 'New Customers Only';
                                   templist.push(each);
                             }
                           }
                        }
                        $scope.list1 = templist;
                   });
          });
        });
      } // end of else

   }; // end of updateTokens
   // *** end rebate-tokens update

   // *** begin - offers update code

    //console.log($scope.list.length);
    if ($scope.list.length < 1) {
     // show /hide create button for offers
      $("#createpercentoffers").show();
     }
    $scope.editingData = {};
    for (var i = 0, length = $scope.list.length; i < length; i++) {
        $scope.editingData[i] = false;
    }
    $scope.modify = function(index){
        $scope.editingData[index] = true;
    };
    $scope.update = function(index,each){
        // validate
        if (isNaN(each.value)){
               $window.alert('Please enter Reward Percentage as numeric value.');
               return;
        } else
        {
           var updateId = $scope.list[index]._id;
           $scope.editingData[index] = false;
           var dataObject = {
            'offer_position': each.offer_position,
            'name': each.name,
            'value': each.value,
            'active': true,
            'merchant_id':each.merchant_id,
            'hot': true,
            'new':false,
            'type':1,
            'acl': JSON.parse('{"*": { "read": true,"write": true}}')
           }
           Merchants.updateOffer("tophat", updateId).then(function () {
             Merchants.createOffer(dataObject).then(function(){
                   Merchants.getOffers(null, true).then(function (result){
                        $scope.list = result;
                   });
             });
           });
        }
   };

   /*$scope.delete = function(index){
       var updateId = $scope.list[index]._id;
       Merchants.updateOffer("tophat", updateId).then(function () {
           Merchants.getOffers(null,true).then(function (result){
                    $scope.list = result;
           });
       });
   }*/

    // *** end - offers update code

    // *** begin - punch offers update

    $scope.list2 = [];
    var punchList = [];
    for(var each, i = 0; i < toffers.length; i++) {

      //if (toffers[i].map_location)
      //{
        each = toffers[i];
        var tokenIdStr = toffers[i].token_id ;
        if (toffers[i].type == 'PUNCH')
        {
          // allow only not extended punch tokens ie allow only token_id - self or empty
          if (tokenIdStr == 'self' || typeof tokenIdStr == 'undefined' || tokenIdStr.length == 0 ) {
             punchList.push(each);
          }
        }
      //}
    }
    $scope.list2 = punchList;
    /* following code when punch is needed to be editable
    $scope.editingDataPunch = {};
    for (var i = 0, length = $scope.list2.length; i < length; i++) {
        $scope.editingDataPunch[i] = false;
    }

    $scope.modifyPunch = function(index){
        $scope.editingDataPunch[index] = true;
    };

    $scope.updatePunch = function(index,each){
        var updateId = $scope.list2[index]._id;
        $scope.editingDataPunch[index] = false;
        var dataObject = {
            'batch': each.batch,
            'seq_start': each.seq_start,
            'seq_end': each.seq_end,
            'merchant_id': each.merchant_id,
            'merchant_name': each.merchant_name,
            'type': each.type,
            'value': each.value,
            'user_list': each.user_list,
            'version': each.version,
            'txn_value': each.txn_value,
            'coupon_name': each.coupon_name,
            'image': each.image,
            'limit_pertoken': each.limit_pertoken,
            'coupon_code': each.coupon_code,
            'map_location': each.map_location,
            'tiered': each.tiered,
            'token_id': each.token_id,
            'active': true,
            'acl': JSON.parse('{"*": { "read": true,"write": true}}')
        }
        Merchants.updateOffer("punch", updateId).then(function () {
             Merchants.createToken(dataObject).then(function(){
                   Merchants.getActiveTokenOffers(null).then(function (result){
                        $scope.list2 = result;
                        // filter list2 for punch
                   });
             });
        });
    }; */
    // *** end - punch offers update


   // *** begin - banner update code
    $scope.editingDataBanner = {};
    $scope.editingDataBanner[0] = false;

    $scope.modifyBanner = function(index){
        $scope.editingDataBanner[index] = true;
    };
    $scope.updateBanner = function(index,bn){

           var updateId = $scope.merchant._id;

           //console.log("updateId   " + updateId);
           //console.log("bn   " + bn);

           Merchants.updateBanner('banner', updateId, bn).then(function () {
                $scope.editingDataBanner[0] = false;
           });
    };


    // *** end - banner update code



   // check for int value
   function isInt(value)
   {
     var x;
     if (isNaN(value)) {
       return false;
     }
     x = parseFloat(value);
     return (x | 0) === x;
   }

  // catch event from modal rebate Create New Rebate Coupon popup on add
  $rootScope.$on('modal-okayed', function (event, modalInstance, couponObj) {

     if( $scope.toBeCreated === true){

         $scope.toBeCreated = false;
         var merchant = $rootScope.$merchant;

         // TBD get other values for Coupon
         var dataObject = {

            'batch': " ",
            'seq_start': " ",
            'seq_end': " ",
            'type': couponObj.rType,
            'value': couponObj.reward_amount,
            'version': "a",
            'merchant_name':  merchant.name,
            'merchant_id': merchant._id,
            'txn_value': 10*couponObj.reward_amount,
            'coupon_name': couponObj.couponText,
            'coupon_code': couponObj.couponCode,
            'limit_pertoken': couponObj.restr,
            'map_location': merchant.map_location,
            'image': " ",
            'tiered': couponObj.tType,
            'active': true,
            'acl': JSON.parse('{"*": { "read": false,"write": false}}')

          };

          // check if created
          Merchants.createToken(dataObject).then(function(){
                   setTimeout(function() {
                        $window.alert('Rebate Coupon Created');
                   });
                  Merchants.getActiveTokenOffers(null).then(function (result){

                        var templist = [];
                        // filter list1 for new,cpn
                        for(var each, i = 0; i < result.length; i++)
                        {

                           if (result[i].map_location)
                           {
                             each = result[i];
                             if (result[i].type == 'CPN')
                             {
                                  if (result[i].limit_pertoken)
                                  {each.restr= 'Limit ' + result[i].limit_pertoken + ' per Customer';}
                                  else
                                  { each.restr= 'None';}
                                    templist.push(each);
                             }
                             else if (result[i].type == 'NEW')
                             {
                                   each.restr= 'New Customers Only';
                                   templist.push(each);
                             }
                           }
                        }
                        $scope.list1 = templist;
                   });
          });
       }
  });

   // call create new rebate coupons popup
   $scope.showDetails = function () {
     $scope.toBeCreated = true;
     $scope.info = [{type:'NEW', name:'New Customers Only'},{type:'CPN', name:'General Coupon'}];
     $scope.tinfo = [{type:'True'},{type:'False'}];

     $scope.openW('lg' );
   };

   $scope.openW = function (size) {

     var modalInstancevar = $modal.open({
     templateUrl: 'myModalContentC.html',
     controller: 'ModalInstanceCtrl',
     size: size,
     resolve: {
               info: function () {
               return $scope.info;},
               tinfo : function(){
               return $scope.tinfo;}
             }
     });
   };

   // call create new offers popup
   $scope.createpercentOffers = function () {
     $scope.toBeCreated = true;
     //console.log("in createpercentOffers");
     $scope.openWF('lg' );
   };

   $scope.openWF = function (size) {

     var modalInstancevar = $modal.open({
     templateUrl: 'myModalContentOffersC.html',
     controller: 'ModalInstanceOffersCtrl',
     size: size
     });
   };

    // merchant rebate create new popup controller
    // catch event from modal rebate Create New Rebate Coupon popup on add
     $rootScope.$on('offermodal-okayed', function (event, modalInstance, offerObj) {

         if( $scope.toBeCreated === true){

             $scope.toBeCreated = false;
             var merchant = $rootScope.$merchant;
             var dataObject = {
                'offer_position': offerObj.offerPosition,
                'name': offerObj.offerName,
                'value': offerObj.rewardPercentage,
                'active': true,
                'merchant_id':merchant._id,
                'hot': true,
                'new':false,
                'type':1,
                'acl': JSON.parse('{"*": { "read": true,"write": true}}')
             }
             Merchants.createOffer(dataObject).then(function(){
                setTimeout(function() {
                   $window.alert('Offer Created');
                });
                 Merchants.getOffers(null, true).then(function (result){
                     $scope.list = result;
                 });
             });
         }
      });

  }); // end of OffersCtrl




  angular.module('merchantWebapp').controller('ModalInstanceCtrl', function ($scope, $modalInstance, $window, info, tinfo) {
    $scope.info = info;
    $scope.tinfo = tinfo;
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    $scope.add = function (rebateForm) {
      var couponObj = {};
      if (typeof rebateForm.t_type.$modelValue == 'undefined')
      { couponObj.tType = false ;
      }else {
        couponObj.tType = rebateForm.t_type.$modelValue.type ;
      }
      couponObj.rType = rebateForm.r_type.$modelValue.type ;
      couponObj.couponCode = rebateForm.coupon_code.$modelValue ;
      couponObj.couponText = rebateForm.coupon_text.$modelValue ;
      couponObj.restr = rebateForm.restr.$modelValue ;
      couponObj.reward_amount = rebateForm.reward_amount.$modelValue ;
      $modalInstance.close();
      $scope.$emit('modal-okayed', $modalInstance, couponObj);
    };
  });

  // merchant offers create new popup controller
  angular.module('merchantWebapp').controller('ModalInstanceOffersCtrl', function ($scope, $modalInstance, $window) {
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    $scope.add = function (offerForm) {
          var offerObj = {};
          offerObj.offerPosition = offerForm.offer_position.$modelValue ;
          offerObj.offerName = offerForm.offer_name.$modelValue ;
          offerObj.rewardPercentage = offerForm.reward_percentage.$modelValue ;
          $modalInstance.close();
          $scope.$emit('offermodal-okayed', $modalInstance, offerObj);
    };
  });
