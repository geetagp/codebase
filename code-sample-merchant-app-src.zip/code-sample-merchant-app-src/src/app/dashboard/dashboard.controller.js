'use strict';

angular.module('merchantWebapp')
  .controller('DashboardCtrl', function ($scope, $rootScope, $filter, Merchants, System, Charting) {
// redemptions, rewards, enrolledCustomers, payments, merchant ,$timeout

      // show the div
      $("#mainContainer").hide();
      var redemptions =[],
          rewards =[],
          payments=[],
          enrolledCustomers=[],
          overpayment = 0,
          buzzfees=[],
          punchtrns=[];

      var  dataRR;
      $scope.RewRedTxn = 0.00;
      var merchant = $rootScope.$merchant;
      var monthlyFeeTypeStr = '';
      monthlyFeeTypeStr = merchant.monthlyFeeType ;
     // console.log("monthlyFeeTypeStr"+  monthlyFeeTypeStr);
      var merchId = merchant._id // "54625880e4b03d005b62bbc3" ; //booksmart
      Merchants.getRedemptionsS(merchId).then(function (redeemrecords) {
            redemptions =    redeemrecords.map(function (o) {
                             o.redeem_date = o.redeem_date.$date;
                             return o; } );

            Merchants.getRewardsS(merchId).then(function (rewardrecords) {
                rewards =  rewardrecords.map(function (o) {
                           o.txn_date = o.txn_date.$date;
                           return o; } );

                Merchants.getPayments(merchId).then(function (paymentrecords) {
                   payments =  paymentrecords.map(function (o) {
                               o.paid_date = o.paid_date.$date;
                               return o; } );

                    Merchants.getEnrolledCustomers(merchId).then(function (enrollcustomerrecords) {
                       enrolledCustomers =  enrollcustomerrecords.map(function (o) {
                                            o.enroll_date = o.enroll_date.$date;
                                            return o; } );

                       Merchants.getPunchTrns(merchId).then(function (punchtrnsrecords) {
                          punchtrns =  punchtrnsrecords ;

                          Merchants.getOverPayment({overPaymentID:merchId}).then(function (result) {
                          if (result.length > 0) {
                             overpayment = parseFloat(result[0].over_payment);
                          }
                          // for monthly fee type
                          if (typeof monthlyFeeTypeStr != 'undefined' && monthlyFeeTypeStr.length > 0 ){
                           Merchants.getBuzzubFees(merchId).then(function (buzzubfeesrecords) {
                               //console.log("buzzubfeesrecords"+ buzzubfeesrecords.length);
                               buzzfees = buzzubfeesrecords.map(function (o) {
                                            o.accrueDate = o.accrueDate.$date;
                                           return o; } );

                           setMerchantStatisticsDetails(redemptions, rewards, payments, enrolledCustomers, merchant, overpayment, buzzfees, punchtrns);
                           });
                          }
                          else{
                            setMerchantStatisticsDetails(redemptions, rewards, payments, enrolledCustomers, merchant, overpayment, buzzfees, punchtrns);
                          }
                    });
                });
            });
         });
      });
   });


   function setMerchantStatisticsDetails(redemptions, rewards, payments, enrolledCustomers, merchant, overpayment, buzzubfees, punchtrns )
   {
    //  $rootScope.loading = false; // hide spinner
    var cRed = (redemptions||[]).map(function (o) { return o.customer_userid; });
    var  cRew   = (rewards||[]).map(function (o) { return o.customer_user._id; });
    var  cEnr   = (enrolledCustomers||[]).map(function (o) { return o.user_id._id; });
    var  merchantCustomers = d3.set(cRed.concat(cRew , cEnr)).values();

    //Activity report
    var dtostr = $filter('date');
    var totRewRed= rewards.concat(redemptions);

    $scope.dTotRewRed = d3.nest().key(function(d) { if (d.customer_user){return d.customer_user._id ;} else if(d.customer_userid) {return d.customer_userid;} else {return d.customer_id;} })
                                            .rollup(function (gelms) { return gelms.length;}).entries(totRewRed);

    function calcRew(startDate, endDate)
    {
      var fcumulativeRewards =[];
      fcumulativeRewards = rewards;

      if (startDate && endDate) {
       fcumulativeRewards = _.filter(rewards,
                           function(o)
                           { var dObj = new Date(o.txn_date);
                           return dObj  >= startDate && dObj <= endDate;});
      }

      return fcumulativeRewards;
    }

    function calcRed(startDate, endDate)
    {
      var fcumulativemoney =[];
      fcumulativemoney = redemptions;
      if (startDate && endDate) {

        fcumulativemoney = _.filter(redemptions,
                           function(o)
                           { var dObj = new Date(o.redeem_date);
                           return dObj  >= startDate && dObj <= endDate;});
      }


      return fcumulativemoney;
    }

    function calcEnr(startDate, endDate)
    {
      var fenrolledCustomers =[];
      fenrolledCustomers = enrolledCustomers ;
      if (startDate && endDate) {

        fenrolledCustomers = _.filter(enrolledCustomers,
                           function(o)
                           { var dObj = new Date(o.enroll_date);
                           return dObj  >= startDate && dObj <= endDate;});

      }
      return fenrolledCustomers;
    }

    $scope.gendate = new Date();
    var y = $scope.gendate.getFullYear(),
    m = $scope.gendate.getMonth(),
    d = $scope.gendate.getDate(),
    currWkStart1,start_d, end_d,
    day = $scope.gendate.getDay(), // Sun -0 , Mon -1
    startDate, // get last  week monday
    endDate, // end of last week Sunday
    startCurrDate,
    lastWkRew, lastWkRed, lastWkEnr,
    currRew, currRed, currEnr;

    currWkStart1 = d - day + 1; // get current week start Mon

    start_d = d - day - 6;
    end_d = d - day +1;

    startDate = new Date(y, m, start_d);
    endDate = new Date(y, m, end_d);

    startCurrDate = new Date(y, m, currWkStart1);

    lastWkRew = calcRew(startDate, endDate);
    lastWkRed = calcRed(startDate, endDate);
    lastWkEnr = calcEnr(startDate, endDate);

    currRew = calcRew(startCurrDate, $scope.gendate);
    currRed = calcRed(startCurrDate, $scope.gendate);
    currEnr = calcEnr(startCurrDate, $scope.gendate);

    var lwRed = (lastWkRed||[]).map(function (o) { return o.customer_userid; }),
          lwRew   = (lastWkRew||[]).map(function (o) { return o.customer_user._id; }),
          lwEnr   = (lastWkEnr||[]).map(function (o) { return o.user_id._id; }),
          lw_merchantCustomers = d3.set(lwRed.concat(lwRew , lwEnr)).values();
    $scope.lw_merchantCustomers = lw_merchantCustomers.length;

    var crRed = (currRed||[]).map(function (o) { return o.customer_userid; }),
          crRew   = (currRew||[]).map(function (o) { return o.customer_user._id; }),
          crEnr   = (currEnr||[]).map(function (o) { return o.user_id._id; }),
          cr_merchantCustomers = d3.set(crRed.concat(crRew , crEnr)).values();
    $scope.cr_merchantCustomers = cr_merchantCustomers.length;

    //$scope.gByCustRewards = d3.nest().key(function (a) { return a.customer_user._id; }).rollup(function (gelms) { return gelms.length;}).entries(rewards);
    $scope.lwcntRepeat = 0;


    lw_merchantCustomers.map(function(obj){
                                      for (var i = 0 ; i < $scope.dTotRewRed.length ; i++){
                                          var objMC = $scope.dTotRewRed[i];
                                          if ((obj == objMC.key)) {
                                             if (objMC.values > 1)
                                             $scope.lwcntRepeat ++;
                                              break;
                                            }
                                      }

                                   });

    $scope.crcntRepeat = 0;
    cr_merchantCustomers.map(function(obj){
                            for (var i = 0 ; i < $scope.dTotRewRed.length ; i++){
                                var objMC = $scope.dTotRewRed[i];
                                if ((obj == objMC.key)) {
                                   if (objMC.values > 1)
                                   $scope.crcntRepeat ++;
                                    break;
                                  }
                            }

                         });


    $scope.lastRed = lastWkRed.length;
    $scope.lastRedAmt = d3.round(d3.sum((lastWkRed||[]).map(function (o) { return o.amount; })),2);
    $scope.currRed = currRed.length;
    $scope.currRedAmt = d3.round(d3.sum((currRed||[]).map(function (o) { return o.amount; })),2);
    $scope.lastEnr = lastWkEnr.length;
    $scope.currEnr = currEnr.length;

    $scope.lastRew = lastWkRew.length;
    $scope.lastRewAmt = d3.round(d3.sum((lastWkRew||[]).map(function (o) { return o.reward_amount; })),2);
    $scope.currRew = currRew.length;
    $scope.currRewAmt = d3.round(d3.sum((currRew||[]).map(function (o) { return o.reward_amount; })),2);

    //$scope.plwcntRepeat = d3.round((parseInt($scope.lwcntRepeat) * 100 / parseInt($scope.lastRew)),0);
    if ($scope.lw_merchantCustomers > 0)
    $scope.plwcntRepeat = d3.round((parseInt($scope.lwcntRepeat) * 100 / parseInt($scope.lw_merchantCustomers)),0);
    else
    $scope.plwcntRepeat = 0;

    if ($scope.cr_merchantCustomers > 0)
    $scope.pcrcntRepeat = d3.round((parseInt($scope.crcntRepeat) * 100 / parseInt($scope.cr_merchantCustomers)),0);
    else
    $scope.pcrcntRepeat = 0;

    //End of activity report

    $scope.cntCustomers = merchantCustomers.length;
    $scope.sumLoyalty = d3.sum((redemptions||[]).map(function (o) { return o.amount; }));
    $scope.sumTransactions = d3.sum((rewards||[]).map(function (o) { return o.txn_amount; }));
    $scope.cntTransactions = redemptions.concat(rewards, punchtrns).length  // add punch transactions ; remove enrolledCustomers,

    $scope.$watch('duration', function (newValue, oldValue) {
      if (oldValue === undefined) {
        return; // avoid rendering twice initially
      }
      var startDate,
        endDate,
        today = new Date(),
        y = today.getFullYear(),
        m = today.getMonth(),
        d = today.getDate(),
        startOfToday = new Date(y, m, d, 0,0,0,0),
        endOfToday = new Date(y, m, d, 23,59,59,999),
        startOfMonth = new Date(y, m, 1),
        endOfMonth = new Date(y, m+1, 1);
        //startOfMonth = new Date(y, m-3, 1), // testing
        //endOfMonth = new Date(y, m-2, 1);   // testing
        //console.log("startOfMonth"+startOfMonth);
        //console.log("endOfMonth "+endOfMonth );

      switch(newValue) {
        case 'day':
          startDate = startOfToday;
          endDate = endOfToday;
          break;
        case 'month':
          startDate = startOfMonth;
          endDate = endOfMonth;
          break;
        default:
          startDate = endDate = null;
          break;
      }
      updateTotals(startDate, endDate);
    });

    $scope.transactions = sparkline(
      redemptions.concat(rewards, enrolledCustomers),
      'redeem_date,txn_date,enroll_date',
      'Transactions', '#23AE89', rollup()
    );
    $scope.loyalty = sparkline(redemptions, 'redeem_date', 'Loyalty Spent', '#FFB61C', rollup('amount'), true);
    $scope.earnings = sparkline(rewards, 'txn_date', 'Earnings', '#E94B3B', rollup('txn_amount'), true);
    // customer need to be sorted and collated based on their first appearance in the universe
    var uniques = {};
    redemptions.concat(rewards, enrolledCustomers).forEach(function (o) {
      var id = o.customer_userid || o.customer_user || o._id,
        dt = o.enroll_date || o.redeem_date || o.txn_date;
      if ((!uniques.hasOwnProperty(id)) || uniques[id].cust_date > dt) {
        uniques[id] = { cust_id: id, cust_date: dt };
      }
    });
    $scope.customers = sparkline(d3.values(uniques), 'cust_date', 'Customers', '#2EC1CC', rollup());

    $scope.redemptions = {};

    // show all by default
    $scope.duration = 'all';
    updateTotals();


    var l = $scope.loyalty,
        r = $scope.redemptions;
    // l.totalAmt = d3.sum([l.rewards.net, l.enrollments.net, l.referrals.net, l.subsidy.net, l.fees.net]); // old code
    // l.rewards.net is -ve ; l.fees.net is -ve so will get added; l.discounts.net is +ve so will get subtracted
    // if  l.totalAmt stays -ve then 'you owe' ; if +ve then 'you have'
    l.totalAmt = d3.sum([l.rewards.net, l.fees.net, l.discounts.net]); // to support new fee type ; works for both old and new merchants
    l.recent = (l.list = rewards).slice(0, 10);

    r.totalAmt = r.net;
    r.recent = (r.list = redemptions).slice(0, 10);

    $scope.payments = {};
    $scope.payments.recent = ($scope.payments.list = payments).slice(0, 10);

    // check if overpayment is applicable
    // instead of showing overpayment on screen - adjust it at l.rewards.used
    $scope.overpayment = 0;
    if ( l.totalAmt < 0) { // check first if merchant owes
       if (overpayment > 0 ) {
         // unpaid with overpayment
         // compute total amount - this is to keep consistent with merchant collection unpaid value displayed
         // since total amount is negative to show merchant owes, add overpayment to get the difference
         $scope.overpayment = Number(overpayment.toFixed(2));
         l.totalAmt = Number(l.totalAmt + $scope.overpayment).toFixed(2) ;

         //$("#regular").hide();
         //$("#overpay").show();
       }
       else{
           // no overpayment
            //$("#regular").show();
            //$("#overpay").hide();
       }
    }
    else{
        // credit
        //$("#regular").show();
        //$("#overpay").hide();
    }

    Merchants.getCustomerTravel().then(function (response) {
      var counts = {},
        entries = d3.entries(response);
      entries.forEach(function (each) {
        var count = d3.set(each.value).values().length,
          label = count;
        counts[label] = counts[label] || 0;
        counts[label]++;
      });

      counts[0] = merchantCustomers.length - entries.length;

      $scope.visitations = {
        config: pieChart({
          x: function(d) {
            if(d.key == 0) { return 'Visited only you'; }
            return 'Visited ' + d.key + ' others';
          }
        }),
        data: d3.entries(counts).sort(function (a, b) {
          return a.key - b.key;
        })
      };
    });

    // 1,234 - 2,000
    // 11,230 - 12,000
    // 111,300 - 112,000
    // 7,726,563 - 8,000,000
    // 18,523,922 - 19,000,000
    // 123,456,789,123 - 124,000,000,000
    function customRound(val) {
      val = String(Math.ceil(val));
      var significant,
        multiplier,
        l = Math.min(val.length-1, 3),
        groupBy;

      significant = !!(val.length % l) ? (Number(val.slice(0, val.length % l)) + 1) : (Number(val.slice(0, l)) + 1);
      multiplier = Math.pow(Math.pow(10, l), Math.ceil(val.length / l) - 1);


      if (significant < 5) {
        groupBy = multiplier / 2;
      }
      else if (significant > 15) {
        var tmp = significant;
        groupBy = multiplier;
        while (tmp > 15) {
          groupBy = groupBy * 2;
          tmp = tmp / 2;
        }
      }
      else {
        groupBy = multiplier;
      }

      return {
        limit: significant * multiplier,
        groupBy: groupBy
      };
    }

    var spendingGroups = d3.nest()
      .key(function(d) { return d.customer_user._id; })
      .rollup(function (leaves) { return d3.sum(leaves, function (each) { return each.txn_amount; }); })
      .entries(rewards)
    ;

    var max = d3.max(spendingGroups, function (g) { return g.values; }),
      crnd = customRound(max),
      maxRound = crnd.limit,
      groupFactor = crnd.groupBy,
      scale = d3.scale.threshold().domain(d3.range(0, maxRound, groupFactor))
        .range([].concat(d3.range(0, maxRound+1, groupFactor)))
    ;

    spendingGroups = d3.nest()
      .key(function (grp) { return scale(grp.values)-groupFactor; })
      .sortKeys(function (a, b) { return Number(a) - Number(b); })
      .rollup(function (leaves) { return leaves.length; })
      .entries(spendingGroups)
    ;

    var allKeys = [];
    for (var i=0; i<=maxRound-1; i+=groupFactor) {
      allKeys.push(i);
    }

    $scope.spendings = {
      config: histogram({}),
      data: [{
        key: 'Spendings',
        values: allKeys.map(function(each ) {
          var existing = spendingGroups.filter(function (o) { return o.key == each; });
          return existing[0] || { key: each, values: undefined } ;
        })
      }]
    };

    function updateTotals(startDate, endDate) {

      //fEnrolledCustomers = angular.copy(enrolledCustomers),
      //var fRewards = angular.copy(rewards),
      //fRedemptions = angular.copy(redemptions),

       var fRewards = [];
           fRewards = rewards;
       var fRedemptions  = [];
            fRedemptions = redemptions;
       var fBuzzfees  = [];
            fBuzzfees = buzzfees;
       var flt = function (fld) {
          return function (o) {
            return o[fld] >= startDate && o[fld] <= endDate;
          };
        };

//     test code
/*
       var testresult =0;
       for (var p = 0; p<fRewards ; p++){
           var diff = fRewards[p].merch_cost - fRewards[p].reward_amount;
           testresult += diff;
       }
       console.log(" fees :" + testresult);
*/
//     end of test code

      if (startDate && endDate) {
        fRewards = fRewards.filter(flt('txn_date'));
        fRedemptions = fRedemptions.filter(flt('redeem_date'));
        fBuzzfees = fBuzzfees.filter(flt('accrueDate'));  // for monthly fee type
        //fEnrolledCustomers = fEnrolledCustomers.filter(flt('enroll_date'));
      }

      var m = merchant,
        r,
        l = $scope.loyalty;

      l.rewards = {
        //change mech_cost back to reward_amount
        earned: d3.sum((fRewards||[]).map(function (o) { return o.reward_amount || 0; })),
        used: d3.sum((fRewards||[]).map(function (o) { return o.collected === true ? o.reward_amount : 0; }))
      };
      // adjust / settle for overpayment, if any
      if ( l.totalAmt < 0) { // check first if merchant owes
         if (overpayment > 0 &&  l.rewards.used > 0) {
          l.rewards.used =  Number(l.rewards.used + overpayment).toFixed(2);
         }
      }
      if ( typeof monthlyFeeTypeStr != 'undefined' && monthlyFeeTypeStr.length > 0 ){
        l.fees = {
           earned: d3.sum((fBuzzfees||[]).map(function (o) { return o.baseFee || 0; })),
           used: d3.sum((fBuzzfees||[]).map(function (o) { return o.collected === true ? o.baseFee : 0; }))
        };
      }
      else {
         l.fees = {
           //fees = merch_cost - reward_cost Number(o.merch_cost - o.reward_amount).toFixed(2)
           earned: d3.sum((fRewards||[]).map(function (o) { return o.merch_cost - o.reward_amount || 0; })),
           used: d3.sum((fRewards||[]).map(function (o) { return o.collected === true ? o.merch_cost - o.reward_amount : 0; }))
         };
      }

      l.buzzdiscounts = {
        earned: d3.sum((fBuzzfees||[]).map(function (o) { return o.discount || 0; })),
        used: d3.sum((fBuzzfees||[]).map(function (o) { return o.collected === true ? o.discount : 0; }))
      };
      l.enrollments = {
        earned: Number(System.calculateEnrollmentBonus(m.enrollment_bonus_id, m.customer_enrollments) || 0),
        used: Number(m.used_enrollment_bonus || 0)
      };
      l.referrals = { earned: Number(m.earned_referral_bonus || 0), used: Number(m.used_referral_bonus || 0) };

      l.subsidy = {
        earned: Number(System.calculateSubsidies(m._id) || 0),
        used: Number(m.used_subsidy || 0)
      };
      if (typeof monthlyFeeTypeStr != 'undefined' && monthlyFeeTypeStr.length > 0 ){
         l.discounts = {
         earned:  d3.sum([l.buzzdiscounts.earned, l.referrals.earned, l.subsidy.earned]),
         used: d3.sum([l.buzzdiscounts.used, l.referrals.used, l.subsidy.used])
         };
      }
      else{
         l.discounts = {
         earned:  d3.sum([l.enrollments.earned, l.referrals.earned, l.subsidy.earned]),
         used: d3.sum([l.enrollments.used, l.referrals.used, l.subsidy.used])
         };
      }
      plugCalculations(l, 'enrollments,referrals,subsidy,rewards,fees,discounts');
      l.rewards.net *= -1;
      //console.log("l.rewards.net" + l.rewards.net);
      l.fees.net *= -1;  // fees net should be shown negative
      //console.log("l.fees.net abc " + l.fees.net);
      r = angular.extend($scope.redemptions, {
        earned: d3.sum((fRedemptions||[]).map(function (o) { return o.amount || 0; })),
        used  : d3.sum((fRedemptions||[]).map(function (o) { return o.paid === true ? o.amount : 0; }))
      });

      r.net = r.earned - r.used;
      //console.log("l.rewards.net ascvb" + l.rewards.net);
    }
    function plugCalculations(o, props) {
      props.split(',').forEach(function (prop) {
        var v = o[prop];
        v.net = v.earned - v.used;
      });
    }

    function sparkline(data, groupBy, key, color, rfn, currency) {
      var dtostr = $filter('date'),
        vals = d3.nest()
          .key(function(d) {
            var fld;
            groupBy.split(',').forEach(function (g) { if (d[g]) { fld = d[g]; } });
            return dtostr(fld, 'yyyy-MM-dd');
          }).sortKeys(d3.ascending)
          .rollup(rfn)
          .entries(data),
        cumulativeSum = 0,
        cumulative = [];

      vals.forEach(function (o) {
        cumulativeSum += o.values;
        o = angular.copy(o);
        o.values = cumulativeSum;
        cumulative.push(o);
      });

      return {
        config: angular.copy(Charting.dashboard.sparklines(currency ? '$' : '')),
        data : [
          { key: key + '(cml)', color: color, values: cumulative },
          { key: key, color: '#ddd', values: vals }
        ]
      };
    }

    function pieChart(config) {
      return {
        chart: {
          type: 'pieChart',
          height: 350,
          margin: { left: 0, right: 0, top: 0, bottom: 0 },
          showLabels: true,
          transitionDuration: 500,
          labelThreshold: 0.01,
          labelType: 'value',
          pieLabelsOutside: false,
          color: ['#8dd3c7','#bebada','#fb8072','#80b1d3','#fdb462','#b3de69','#fccde5','#d9d9d9','#bc80bd','#ccebc5','#ffed6f'],
          tooltips: false,
          x: config.x || function (d) { return d.key; },
          y: function(d) { return parseInt(d.value || d.values, 10); },
          legend: {
            margin: {
              top: 15,
              right: 35,
              bottom: 0,
              left: 0
            }
          },
          showLegend: true
        }
      };
    }

    function histogram(config) {
      return {
        chart: {
          type: 'discreteBarChart',
          height: 300,
          margin: { left: 30, right: 30, top: 30, bottom: 70 },
          showLabels: true,
          showValues: false,
          transitionDuration: 500,
          labelThreshold: 0.01,
          labelType: 'value',
          color: ['#80b1d3'],
          tooltips: true,
          valueFormat: ',',
          x: config.x || function (d) { return d.key + '-' + (Number(d.key)+groupFactor); },
          y: function(d) { return parseInt(d.value || d.values, 10); },
          xAxis: { rotateLabels: 45 },
          yAxis: { tickFormat: d3.format('d') },
          showXAxis: true,
          showYAxis: true,
          showLegend: false
        }
      };
    }

    function rollup(sumFld) {
      return sumFld ?
        function (leaves) {
          return d3.sum(leaves, function (o) { return o[sumFld];});
        } :
        function (leaves) {
          return leaves.length;
        };
    }

    // show the div
    $("#mainContainer").show();
    /**end of code for merchants dashboard ***/
  } // end of function
 });
