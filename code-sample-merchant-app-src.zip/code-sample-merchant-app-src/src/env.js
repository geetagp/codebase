angular.module('netincent.config', [])
.constant('brandingConstants', {"k4m":{"title":"Kash4me","homepage":"http://www.kash4me.com/","themeFile":"theme-k4m"},"thr":{"title":"Buzzub Rewards","homepage":"http://www.tophatrewards.com/","themeFile":"theme-thr"}});

angular.module('netincent.config')
.constant('apperyConstants', {"baseURL":"https://api.appery.io/rest/1/","dbID":"57522886e4b05934dbf207a3","fnGetCustBalance":"6b4e6179-da1a-412a-9b48-1bf929a6a941","fnUpdatePassword":"b78b04fe-49ae-46a8-af01-56daa0190b70","fnSendRecoveryInfoText":"84b39111-7652-42dc-aa16-d820eca86ac0","fnResetPassword":"c24f0f34-7719-4710-a694-9881dd2c11ed","fnCreateMerchant":"afd6cfcc-4720-47b2-8658-23fef4032663","fnGetCustomersTravel":"99811df6-1b7c-48d5-8620-ee9119826801","fnGetTokenInfo":"da522f4c-66b4-4a71-a2d2-28c48ecd4b6c","fnGetMerchantInfo-v2":"5021ad41-5ad4-4e98-aa3b-a3785d9d756f","fnGetMerchantStats":"c6bc1020-d4e5-4156-b147-e82e30aba42b","fnGetMerchantCollected":"175564d6-9360-4908-98b9-addb074f60a0"})
.constant('herokuConstants', {"payServer":"https://shielded-brook-9722.herokuapp.com/"});
