'use strict';

angular.module('merchantWebapp', [
  'ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngStorage', 'ui.router', 'ui.bootstrap',
  'netincent.config', 'netincent.ui.util', 'netincent.appery', 'netincent.rest'])

  .controller('LoginCtrl', function ($scope, $rootScope, $window, $modal, Session, Merchants) {
    $scope.qs = $window.location.search.replace(/^\?/,'') || 'thr';

    $scope.username = $scope.password = '';
    loadPersistedUserData();

    $scope.onSubmit = function () {
      var uname = $scope.username,
        pwd = $scope.password;

      if (uname && pwd) {
        $window.localStorage.remember_me = $scope.remember_me === true;
        verifyLogin(uname, pwd).then(
          function (result)
          {
            if (result.brand == "sys"){
                handleError();
                return;
              }
            if ($scope.primary)
            $window.location.replace('app.html?' + $scope.qs);
            else handleError();
             },
          function ()
          { handleError(); }

        );
      }
    };

    $scope.modalForgot = namedModal({
      id: 'forgot-pwd',
      templateUrl: 'forgotPassword.html',
      controller: 'ModalInstanceCtrl'
    });

    $scope.modalReset = namedModal({
      id: 'reset-pwd',
      templateUrl: 'resetPassword.html',
      controller: 'ModalInstanceCtrl'
    });

    $rootScope.$on('modal-okayed', function (event, modalInstance, value) {
      if (modalInstance.id === 'forgot-pwd') {
        if (!value) {
          event.returnValue = false;
          return false;
        }
        Session.resetPasswordSendSecret(value).then(function (response) {
          $scope.modalReset.open({
            resolve: {
              value: function () { return { message: response.message, mobile: value }; }
            }
          });
        });
      }
      else if (modalInstance.id === 'reset-pwd') {
        if (value.pwd !== value.pwdc) {
          value.message = 'Both passwords must match. Please correct and click "Save New Password" again.'
          event.returnValue = false;
          return false;
        }
        Session.resetPassword(value.mobile, value.code, value.pwd).then(
          function (response) {
            $scope.loginMessage = response.message;
            modalInstance.close();
          },
          function (response) {
            $scope.loginError = 'There was an error resetting your password.<br/>Please click "Forgot Password" again.';
            modalInstance.close();
          }
        );
      }
    });

    $scope.showForgotPasswordDialog = function () {
      //$scope.username = formatPhoneNumber($scope.username);
      $scope.modalForgot.open({
        resolve: {
          value: function () { return $scope.username; }
        }
      });
    };

    function formatPhoneNumber(s) {
      var s2 = ("" + s).replace(/\D/g, ''),
        m = s2.match(/^(\d{3})(\d{3})(\d{4})$/);
      return (!m) ? "" : m.slice(1).join('-');
    }

    function namedModal(config) {
      var _modal;
      return {
        open: function (resolve) {
          _modal = $modal.open(angular.extend({}, config, resolve));
          _modal.id = config.id || new Date().getTime();
        }
      };
    }

    function verifyLogin(uname, pwd) {
      return Session.doLogin(uname, pwd)
        .then(function (sessionData) {
          $scope.remember_me === true && persistUserData(uname);
          $window.sessionStorage.sessionToken = sessionData.sessionToken;
          return Session.getCurrentUser(uname);
        }, handleError)
        .then(function (userData) {
                if (userData.secondary == true){
                 $scope.primary = false;
                 //$scope.loginError = true;
                }

                else{
                  $scope.primary = true;
                  return Merchants.get(userData.merchant_id._id)
                                   .then(function (merchData) {
                                     Session.setCurrentMerchant(merchData);
                                     return merchData;
                                   });
                }
        });
    }

    function handleError() {
      $scope.loginError = true;
    }

    function persistUserData(uname) {
      $window.localStorage.username = uname;
    }

    function loadPersistedUserData() {
      $scope.username = $window.localStorage.username || '';
      $scope.remember_me = $window.localStorage.remember_me == true;
    }
  })

  .controller('ModalInstanceCtrl', function ($scope, $modalInstance, value) {
    $scope.value = value;

    $scope.ok = function () {
      var e = $scope.$emit('modal-okayed', $modalInstance, $scope.value);
      if (e && e.returnValue !== false) {
        $modalInstance.close();
      }
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };
  })
;
