'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')({
  pattern: ['gulp-*']
}),
  ftpPasswd;

gulp.task('deploy:dev', [], function () {
  return gulp.src(['dist'])
    .pipe($.rsync({
      root: 'dist',
      hostname: 'netincent.org',
      username: 'netincentorg',
      clean: true,
      recursive: true,
      destination: '/home/netincentorg/netincent.org/merchant'
    }));
});

gulp.task('deploy:prod', [], function () {
  return gulp.src(['dist'])
    .pipe($.rsync({
      root: 'dist',
      hostname: 'kash4me.com',
      username: 'kash4me',
      clean: true,
      recursive: true,
      destination: '/home/kash4me/kash4me.com/merchant'
    }));
});

/*
// obsolete FTP method of transferring files

gulp.task('deploy:dev', [], function () {
  return gulp.src(['dist/**'])
    .pipe($.ftp({
      host: 'netincent.org',
      user: 'netincentorg',
      pass: 'Nnb-d6F-8Sk-fBM',
      remotePath: '/netincent.org/merchant'
    }));
});

gulp.task('deploy:prod', [], function () {
  return gulp.src(['dist/**'])
    .pipe($.sftp({
      host: 'kash4me.com',
      user: 'kash4me',
      remotePath: '/kash4me.com/merchant'
    }));
});

*/
