'use strict';

var gulp = require('gulp'),
  gulpNgConfig = require('gulp-ng-config'),
  streamqueue = require('streamqueue'),
  gulpConcat = require('gulp-concat'),
  gulpRename = require('gulp-rename');

// inject bower components
gulp.task('wiredep', function () {
  var wiredep = require('wiredep').stream;

  return gulp.src('src/{login,app}.html')
    .pipe(wiredep({
      directory: 'bower_components',
      exclude: [/bootstrap-sass-official/, /bootstrap\.css/, /bootstrap\.css/, /foundation\.css/]
    }))
    .pipe(gulp.dest('src'));
});

function env(mode) {
  return streamqueue({ objectMode: true },
    gulp.src('env/common-constants.json').pipe(gulpNgConfig('netincent.config')),
    gulp.src('env/' + mode + '-constants.json').pipe(gulpNgConfig('netincent.config', {createModule: false}))
  )
    .pipe(gulpConcat('env.js'))
    .pipe(gulp.dest('src'))
  ;

}

gulp.task('env'           , function () { return env('dev'); });
gulp.task('env:dev'       , function () { return env('dev'); });
gulp.task('env:prodclone' , function () { return env('prodclone'); });
gulp.task('env:prod'      , function () { return env('prod'); });
